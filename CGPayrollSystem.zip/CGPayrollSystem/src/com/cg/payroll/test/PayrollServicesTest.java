package com.cg.payroll.test;
import static org.junit.Assert.*;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.daoservices.PayrollDAOServicesImpl;
import com.cg.payroll.exceptions.AssociateDetailsNotFoundException;
import com.cg.payroll.exceptions.PayrollServicesDownException;
import com.cg.payroll.services.PayrollServices;
import com.cg.payroll.services.PayrollServicesImpl;
public class PayrollServicesTest {
	/*private static PayrollServices payrollServices;
	@BeforeClass
	public static void setUpTestEnv() {
		payrollServices= new PayrollServicesImpl();
	}
	@Before
	public void setUpMockData() {	
		PayrollUtility.ASSOCIATE_ID_COUNTER=111;
		Associate associate1 = new Associate(PayrollUtility.ASSOCIATE_ID_COUNTER++,15000, "Satish", "Mahajan", "Training", "Sr Con", "AD13SDK23", "satish@gmail.com", new Salary(15000, 1000, 1000), new BankDetails(1234, "HDFC", "HDFC0002"));	
		Associate associate2 = new Associate(PayrollUtility.ASSOCIATE_ID_COUNTER++,100000, "Rakesh", "Nimse", "Training", "Sr Con", "UEUE282K", "rakesh@gmail.com", new Salary(20000, 1000, 1000), new BankDetails(92993, "HDFC", "HDFC2222"));	
		Associate associate3 = new Associate(PayrollUtility.ASSOCIATE_ID_COUNTER++,125000, "Nilesh", "Khole", "Training", "Sr Con", "LSDMDI22K", "Nilesh@gmail.com", new Salary(35000, 1000, 1000), new BankDetails(21313, "HDFC", "HDFC3223"));	
		PayrollDAOServicesImpl.associates.put(associate1.getAssociateID(), associate1);
		PayrollDAOServicesImpl.associates.put(associate2.getAssociateID(), associate2);
		PayrollDAOServicesImpl.associates.put(associate3.getAssociateID(), associate3);	
	}
	@Test
	public void testAcceptAssociateDetailsForValidData() throws PayrollServicesDownException {
		int expectedAssociateId=114;
		int actualAsscoiateId=payrollServices.acceptAssociateDetails("Yogesh", "Raj", "yogesh@gmail.com", "HR", "Sr Manager", "KDIE203Dk", 110000, 30000, 1000, 1000, 122112, "Axis banh", "axsbank2912");
		assertEquals(expectedAssociateId, actualAsscoiateId);
	}	
	@Test(expected=AssociateDetailsNotFoundException.class)
	public void testGetAssociateDetailsForInvalidAssociateId() throws AssociateDetailsNotFoundException, PayrollServicesDownException {
		payrollServices.getAssociateDetails(2100);
	}
	@Test
	public void testGetAssociateDetailsForValidAssociateId() throws AssociateDetailsNotFoundException, PayrollServicesDownException {
		Associate actualAssociate = new Associate(112,100000, "Rakesh", "Nimse", "Training", "Sr Con", "UEUE282K", "rakesh@gmail.com", new Salary(20000, 1000, 1000), new BankDetails(92993, "HDFC", "HDFC2222"));	
		Associate expectedAssociate= payrollServices.getAssociateDetails(112);
		assertEquals(expectedAssociate, actualAssociate);
	}
	@After
	public void tearDownMockData() {
		PayrollDAOServicesImpl.associates.clear();
		PayrollUtility.ASSOCIATE_ID_COUNTER=111;	
	}
	@AfterClass
	public static void tearDownTestEnv() {	
		payrollServices=null;
	}	*/
}