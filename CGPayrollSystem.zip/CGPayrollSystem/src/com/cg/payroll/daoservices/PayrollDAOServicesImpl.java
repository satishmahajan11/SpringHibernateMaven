package com.cg.payroll.daoservices;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import com.cg.payroll.beans.Associate;
@Component(value="payrollDAOServices")
public class PayrollDAOServicesImpl implements PayrollDAOServices {
	
	@Autowired
	private SessionFactory sessionFactory;
	
	@Override
	public int insertAssociate(Associate associate) {
		Session session = sessionFactory.openSession();
		Transaction tx = session.beginTransaction();
		try{
			Integer associateId= (Integer) session.save(associate);
			tx.commit();
			return associateId;
		}
		catch (HibernateException  e) {
			tx.rollback();
			e.printStackTrace();
			throw e;
		}
		finally {
			session.close();
		}	
	}
	@Override
	public boolean updateAssociate(Associate associate) {
		return false;
	}
	@Override
	public boolean deleteAssciate(int associateId) {
		return false;
	}

	@Override
	public Associate getAssociate(int associateId) {
		return (Associate) sessionFactory.openSession().get(Associate.class, associateId);
	}

	@Override
	public List<Associate> getAssociates() {
		Session session = sessionFactory.openSession();
		Query query = session.createQuery("from Associate a");
		return query.list();
	}
	
}
