package com.cg.payroll.main;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.payroll.exceptions.PayrollServicesDownException;
import com.cg.payroll.services.PayrollServices;
public class MainClass {
	public static void main(String[] args) {
			ApplicationContext applicationContext = 
					new ClassPathXmlApplicationContext("projectbeans.xml");
			PayrollServices payrollServices = 
					(PayrollServices)applicationContext.getBean("payrollServices");
	}
}  
